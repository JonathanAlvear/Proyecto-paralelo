﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoParalelo.clases
{
    public class Persona
    {
        public int Id { get; set; }

        public string Nombre { get; set; }

        public string Apellido { get; set; }

        public Empresa Empresa { get; set; }

        public string Presentarse()
        {
            return $"Me llamo {Nombre} {Apellido} ";
        }
    }
}
