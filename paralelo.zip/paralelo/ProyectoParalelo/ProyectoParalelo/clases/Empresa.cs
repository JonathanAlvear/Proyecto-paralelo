﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoParalelo.clases
{
    public class Empresa
    {
        public int Id { get; set; }

        public string Nombre { get; set; }

        public Persona Persona { get; set; }

        public string PresentarPersona()
        {
            return $"Buenas soy el representante de la empresa {Nombre}";
        }
    }
}
