﻿using ProyectoParalelo.clases;
using System;
using System.Threading;

namespace ProyectoParalelo
{
    class Program
    {
        static void Main(string[] args)
        {
           // string path1 = @"C:\Users\shuno\Desktop\Deberes 3 semestre\paralelo\ProyectoParalelo\ProyectoParalelo\clases\";


            var persona1 = new Persona();
            persona1.Nombre = "Seat";
            persona1.Apellido = "Alvear";  

            string presentarse = persona1.Presentarse();

            Console.WriteLine("Hello World!");
            Thread t = new Thread(EscribeY);
            t.Start(); // Arranca EscribeY en un hilo nuevo.
            while (true) Console.Write(presentarse); // Escribe la funcion de presentarse de la persona 
        static void EscribeY()
            {
                var empresa1 = new Empresa();
                empresa1.Nombre = "Lealtity";
                string presentarPersona = empresa1.PresentarPersona();
                while (true) Console.WriteLine(presentarPersona); // Escribe la funcion presentar a la empresa             



                
            }
        }
    }
}
